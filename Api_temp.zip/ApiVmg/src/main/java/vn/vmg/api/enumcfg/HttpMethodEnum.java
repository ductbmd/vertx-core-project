package vn.vmg.api.enumcfg;

public enum HttpMethodEnum {
	POST, GET
}
