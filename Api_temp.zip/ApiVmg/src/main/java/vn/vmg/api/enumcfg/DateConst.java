package vn.vmg.api.enumcfg;


public enum DateConst {
	DATE,MONTH,YEAR,MILLISECOND
}
