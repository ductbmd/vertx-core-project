package vn.vmg.api.impl;

public enum EventIdEnum {
	GET_ALL_SERVICE_AND_PARTNER,
	GET_ALL_INDICATOR_OUTPUT,
	
	
	
	;
}
